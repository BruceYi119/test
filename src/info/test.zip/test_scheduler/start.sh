#!/bin/bash
java -jar -Dspring.profiles.active=$1 ./test_scheduler-1.0.0.jar --spring.config.location=file:./