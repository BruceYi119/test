package com.sefist.mock;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class Constants {
	
	public static Map<String, String> errorMap;
	static {
		errorMap = new HashMap<String, String>();
		
		try {
			errorMap.put("910", new String("시스템 명칭 오류".getBytes("MS949")));
			errorMap.put("911", new String("보고기관코드 오류"));
			errorMap.put("912", new String("전문종별코드 오류"));
			errorMap.put("915", new String("계속 여부 오류"));
			errorMap.put("920", new String("서비스 불가능 상태 오류"));
			errorMap.put("921", new String("업무가 개시 되지 않은 상태임"));
			errorMap.put("922", new String("사용자ID 오류"));
			errorMap.put("923", new String("문서번호중복 오류"));
			errorMap.put("999", new String("기타오류"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

	}

}



	
	
	
	
	
	
	
	
