package com.sefist.mock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;

@Service
public class LogService {

	public static final Logger log = LoggerFactory.getLogger(LogService.class);

	public static String getLogText(String className, String rptFcltyCd, String rptDocNo, String msg) {
		String logText;

		 if (rptFcltyCd != null && rptDocNo != null)
	            logText = String.format("[%-30.30s][%-6.6s %-17.17s] %s", className, rptFcltyCd.trim(), rptDocNo.trim(), msg);
	        else if (rptFcltyCd != null)
	            logText = String.format("[%-30.30s][%-24.24s] %s", className, rptFcltyCd.trim(), msg);
	        else if (rptDocNo != null)
	            logText = String.format("[%-30.30s][%-6.6s% %-17.17s] %s", className, "", rptDocNo.trim(), msg);
	        else
	            logText = String.format("[%-30.30s] %s", className, msg);

		return logText;
	}

	public static String updateLevel(Integer level) {
		String lv = getLevelStr(level);
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		ch.qos.logback.classic.Logger logClass = lc.getLogger(LogService.class);

		logClass.setLevel(Level.toLevel(lv));

		return lv;
	}

	private static String getLevelStr(Integer level) {
		String levelStr = null;

		switch (level) {
		case 1:
			levelStr = Level.TRACE.toString();
			break;
		case 2:
			levelStr = Level.DEBUG.toString();
			break;
		case 3:
			levelStr = Level.INFO.toString();
			break;
		case 4:
			levelStr = Level.WARN.toString();
			break;
		case 5:
			levelStr = Level.ERROR.toString();
			break;
		default:
			levelStr = Level.INFO.toString();
			break;
		}

		return levelStr;
	}

}