package com.sefist.socket;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.sefist.mock.FiuResposeService;
import com.sefist.mock.LogService;
import com.sefist.mock.SefistProperty;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

@Component
public class FiuServer implements ApplicationListener<ApplicationStartedEvent> { 
	private EventLoopGroup bossGroup = new NioEventLoopGroup(1);
	private EventLoopGroup workerGroup = new NioEventLoopGroup();
	private ServerBootstrap bootstrap = new ServerBootstrap();
	
	private int port;
	private InitialHandler handlers;

	@Autowired
	SefistProperty prop;

	public FiuServer(SefistProperty prop, FiuResposeService resService) {
		this.prop = prop;
		this.port = prop.getServerPort();
		
		ArrayList<ChannelHandler> handlers = new ArrayList<ChannelHandler>();
		handlers.add(new ServerHandler(prop, resService));
		this.handlers = new InitialHandler(handlers);
	}

	public void stop() {
    	bootstrap.config().group().shutdownGracefully();
    	bootstrap.config().childGroup().shutdownGracefully();		
	}
	
	@Override
	public void onApplicationEvent(ApplicationStartedEvent event) {
	    bootstrap.group(bossGroup, workerGroup)
	     .channel(NioServerSocketChannel.class)
	     .option(ChannelOption.SO_BACKLOG, 100)
 	     .childHandler(this.handlers);  	

	    try {
		    Channel channel = bootstrap.bind(port).sync().channel();  
		    LogService.log.info(LogService.getLogText(getClass().getSimpleName(), null, null, "FIU Socket Server stared on port " + port));
		    
		    channel.closeFuture().sync();
	    
	    } catch (InterruptedException e) {
			e.printStackTrace();
	    } finally {
	    	bootstrap.config().group().shutdownGracefully();
	    	bootstrap.config().childGroup().shutdownGracefully();
	    }	    
	    
	}

}

