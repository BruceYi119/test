package com.sefist.mock;

public class SefistException extends Exception {
	
	public SefistException(String message) {
		super(message);
	}
}
