package com.sefist.socket;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.sefist.mock.FiuResposeService;
import com.sefist.mock.LogService;
import com.sefist.mock.ModelConstants;
import com.sefist.mock.ModelFactory;
import com.sefist.mock.SefistProperty;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;

@Sharable
public class ServerHandler extends ChannelInboundHandlerAdapter {
	SefistProperty prop;
	FiuResposeService resService;
	
	Map<ChannelId, BufferedOutputStream> bufferMap = new HashMap<ChannelId, BufferedOutputStream>();
	Map<ChannelId, File> fileMap = new HashMap<ChannelId, File>();
	Map<ChannelId, ByteBuf> packetMap = new HashMap<ChannelId, ByteBuf>();
	Map<ChannelId, Integer> mustReadSizeMap = new HashMap<ChannelId, Integer>();
	Map<ChannelId, ModelFactory.Model> modelMap = new HashMap<ChannelId, ModelFactory.Model>();
	
    public ServerHandler(SefistProperty prop, FiuResposeService resService) {
    	this.prop = prop;
    	this.resService = resService;
    }
	
    private void clearBuffer(ChannelHandlerContext ctx) { 
    	if (packetMap.get(ctx.channel().id()) != null) {
    		packetMap.get(ctx.channel().id()).release();
    		packetMap.put(ctx.channel().id(), null);
    	}
    }
    
    @Override
    public void channelActive(ChannelHandlerContext ctx) {
    	ctx.channel().pipeline().addLast(new ReadTimeoutHandler(30));
    	ctx.channel().pipeline().addLast(new WriteTimeoutHandler(30));
    	packetMap.put(ctx.channel().id(), ctx.alloc().buffer());
    	mustReadSizeMap.put(ctx.channel().id(), 0);
    }
    
    @Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
    	clearBuffer(ctx);
    	if(bufferMap.get(ctx.channel().id()) != null) bufferMap.get(ctx.channel().id()).close();

    }
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
    	if(packetMap.get(ctx.channel().id()) == null) packetMap.put(ctx.channel().id(), ctx.alloc().buffer());

    	ByteBuf b = (ByteBuf)msg;	
    	packetMap.get(ctx.channel().id()).writeBytes(b);
    	b.release();
    	
    	while(packetMap.get(ctx.channel().id()).readableBytes() >= 56) {
        	if (mustReadSizeMap.get(ctx.channel().id()) == 0) { 
        		byte[] bytes = new byte[4];
        		packetMap.get(ctx.channel().id()).getBytes(0, bytes);
        		mustReadSizeMap.put(ctx.channel().id(), Integer.parseInt(new String(bytes)));
        		LogService.log.debug(LogService.getLogText(getClass().getSimpleName()
        				, null, null, "[mustReadSize]["+mustReadSizeMap.get(ctx.channel().id())+"] [readBytes]["+packetMap.get(ctx.channel().id()).readableBytes()+"]"));
        	}    		
        	if(packetMap.get(ctx.channel().id()).readableBytes() < mustReadSizeMap.get(ctx.channel().id())) break;
        		
    		byte[] readData = new byte[mustReadSizeMap.get(ctx.channel().id())];
    		packetMap.get(ctx.channel().id()).readBytes(readData);
    		messageRead(ctx, readData);
    		LogService.log.debug(LogService.getLogText(getClass().getSimpleName()
    				, null, null, "[remainedBytes]["+packetMap.get(ctx.channel().id()).readableBytes()+"]"));
    		
    		if(packetMap.get(ctx.channel().id()).readableBytes() >= 56) {
        		byte[] bytes = new byte[4];
        		packetMap.get(ctx.channel().id()).getBytes(0, bytes);
        		
        		if(packetMap.get(ctx.channel().id()).readableBytes() == 73) mustReadSizeMap.put(ctx.channel().id(), 73);
        		else mustReadSizeMap.put(ctx.channel().id(), Integer.parseInt(new String(bytes)));
        		LogService.log.debug(LogService.getLogText(getClass().getSimpleName()
        				, null, null, "[mustReadSize]["+mustReadSizeMap.get(ctx.channel().id())+"] [readBytes]["+packetMap.get(ctx.channel().id()).readableBytes()+"]"));  			
    		}

    		if(packetMap.get(ctx.channel().id()).readableBytes() == 0) {
    			mustReadSizeMap.put(ctx.channel().id(), 0);
				clearBuffer(ctx);
				break;
    		}
    	}
   }
    
    public void messageRead(ChannelHandlerContext ctx, byte[] readData) throws Exception {    
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyymmddHHmmss");
        Calendar c1 = Calendar.getInstance();
        String nowDate  = sdf.format(c1.getTime());
        
		byte[] btyeRecvTelegramCd = new byte[8];
		System.arraycopy(readData, 42, btyeRecvTelegramCd, 0, btyeRecvTelegramCd.length);
		String recvTelegramCd = new String(btyeRecvTelegramCd);
    	
		byte[] btyeResCd = new byte[3];
		System.arraycopy(readData, 53, btyeResCd, 0, btyeResCd.length);   	
		String resCd = new String(btyeResCd);

		byte[] btyeRptFcltyCd = new byte[6];
		System.arraycopy(readData, 16, btyeRptFcltyCd, 0, btyeRptFcltyCd.length);   	
		String rptFcltyCd = new String(btyeRptFcltyCd);	
		
		String rptDocNo = null;
		try {
			rptDocNo = modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim();
		}catch(NullPointerException e) {

		}

		if(recvTelegramCd.equals("03000030")){
	    	LogService.log.info(LogService.getLogText(getClass().getSimpleName(), rptFcltyCd, rptDocNo
	    			, "["+recvTelegramCd+"]["+String.format("%04d", readData.length)+ "]["+resCd+"]"));		
		}else {
	    	LogService.log.info(LogService.getLogText(getClass().getSimpleName(), rptFcltyCd, rptDocNo
	    			, "["+recvTelegramCd+"]["+String.format("%04d", readData.length)+ "]["+resCd+"]["+new String(readData, "EUC-KR")+"]"));					
		}		
		
		String sendMessage = "";
		String sendTelegramCd = "";
		if(recvTelegramCd.equals("06000010")) {
			sendTelegramCd = "06100010";
			System.arraycopy(sendTelegramCd.getBytes(), 0, readData, 42, sendTelegramCd.length());   	
			sendMessage = new String(readData);
			

			modelMap.put(ctx.channel().id(), ModelFactory.getModel(ModelConstants.MODEL_TYPE_RECV, new byte[2167]));
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_TELE_LENGTH, "2167");
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_IF_ID, String.format("%-10s", "PAS1CAP001"));
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD, rptFcltyCd);
			LogService.log.info(LogService.getLogText(getClass().getSimpleName()
					, rptFcltyCd, null, "["+sendTelegramCd+"]["+String.format("%04d", sendMessage.length()) + "]["+resCd+"][" + sendMessage+"]"));
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);

			
		}else if(recvTelegramCd.equals("03000020")){
			int maxSendSize = 5043;
			sendTelegramCd = "03100020";
			System.arraycopy(sendTelegramCd.getBytes(), 0, readData, 42, sendTelegramCd.length()); 
			
			byte[] btyeSendMessage = new byte[195];
			System.arraycopy(readData, 4, btyeSendMessage, 0, btyeSendMessage.length);  
			sendMessage = new String(btyeSendMessage);	

			//이어받기여부(1)
			sendMessage += "N";
			//수신한 길이(10)
			sendMessage += String.format("%010d", 0);
			//수신한 전문길이 반환
			sendMessage = String.format("%04d",sendMessage.length()+4) + sendMessage;
			
			byte[] btyeRptDocNo = new byte[17];
			System.arraycopy(readData, 64, btyeRptDocNo, 0, btyeRptDocNo.length);  
			rptDocNo = new String(btyeRptDocNo);	
			
			byte[] btyeRecvFileNm = new byte[40];
			System.arraycopy(readData, 106, btyeRecvFileNm, 0, btyeRecvFileNm.length);  
			String recvFileNm = new String(btyeRecvFileNm);			
			
			byte[] btyeFileSize = new byte[10];
			System.arraycopy(readData, 189, btyeFileSize, 0, btyeFileSize.length);  
			String fileSize = new String(btyeFileSize);	
			
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RPT_DOC_NO, String.format("%20s", rptDocNo.trim()));
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RPT_STATUS_CD, "RS"); //SR(초기데이터입력), SP(송신요청), SS(송신성공), SF(송신실패), RS(수신성공), RF(수신실패), MC(수기완료)
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RPT_PROC_TYPE, "00"); //00.전송 01. 도착오류 증서 02.가접수증서 03.접수증서 04.재보고수신 05.추가자료요청수신
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, resCd); 
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_PROC_HOST_NM, String.format("%-20s", "MOCK_SERVER")); 
			modelMap.get(ctx.channel().id()).setData(ModelConstants.MODEL_FIELD_RECV_FILE_NM, String.format("%-100s", recvFileNm.trim()));
			modelMap.get(ctx.channel().id()).setFileSize(Integer.parseInt(fileSize));  

			int totSendSeq = (int)(modelMap.get(ctx.channel().id()).getFileSize()/maxSendSize) ;
			if((modelMap.get(ctx.channel().id()).getFileSize() % maxSendSize)!=0) totSendSeq++;
			modelMap.get(ctx.channel().id()).setTotSendSeq(totSendSeq);
		
			fileMap.put(ctx.channel().id(), new File(prop.getRecvFilePath()+File.separatorChar+recvFileNm.trim()));
			bufferMap.put(ctx.channel().id(), new BufferedOutputStream(new FileOutputStream(fileMap.get(ctx.channel().id()))));
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName()
					, rptFcltyCd, modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim(), "["+sendTelegramCd+"]["
						+String.format("%04d", sendMessage.length()) + "]["+resCd+"][" + sendMessage+"]"));
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);
			
		}else if(recvTelegramCd.equals("03000030")){	
			byte[] btyeRecvDataSize = new byte[4];
			System.arraycopy(readData, 73, btyeRecvDataSize, 0, btyeRecvDataSize.length);  
			int recvDataSize = Integer.parseInt(new String(btyeRecvDataSize));

			byte[] recvDataContents = new byte[recvDataSize];
			System.arraycopy(readData, 77, recvDataContents, 0, recvDataContents.length);  

			byte[] byteSeq = new byte[7];
			System.arraycopy(readData, 56, byteSeq, 0, byteSeq.length);  

			modelMap.get(ctx.channel().id()).setSendSeq(Integer.parseInt(new String(byteSeq)));
			modelMap.get(ctx.channel().id()).setRecvSize(modelMap.get(ctx.channel().id()).getRecvSize()+recvDataSize);
			bufferMap.get(ctx.channel().id()).write(recvDataContents);
			
			StringBuilder sb = new StringBuilder();
			sb.append("[03000030]");
			sb.append("["+String.format("%04d", readData.length) + "]");
			sb.append("[000]");
			sb.append("["+String.format("%07d",modelMap.get(ctx.channel().id()).getTotSendSeq())+"]"); 						//전체 시퀀스
			sb.append("["+String.format("%07d",modelMap.get(ctx.channel().id()).getTotSendSeq()-modelMap.get(ctx.channel().id()).getSendSeq())+"]=>");	//남은 시퀀스	
			sb.append("["+String.format("%07d",modelMap.get(ctx.channel().id()).getSendSeq())+"]");							//송신한 시퀀스

			LogService.log.debug(LogService.getLogText(getClass().getSimpleName(), modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD)
					, modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO), sb.toString()));
			
		}else if(recvTelegramCd.equals("03000040")){
//			- ‘00’: 정상, 시퀀스와 크기 둘 다 일치
//			- ‘01’: 시퀀스 불일치
//			- ‘10’: 크기 불일치
//			- ‘11’: 시퀀스와 크기 불일치
			
			sendTelegramCd = "03100040";
			System.arraycopy(sendTelegramCd.getBytes(), 0, readData, 42, sendTelegramCd.length()); 
			
			byte[] btyeSendMessage = new byte[52];
			System.arraycopy(readData, 4, btyeSendMessage, 0, btyeSendMessage.length);  
			sendMessage = new String(btyeSendMessage);				

			byte[] byteRecvSeq = new byte[7];
			System.arraycopy(readData, 56, byteRecvSeq, 0, byteRecvSeq.length);
			int recvSeq = Integer.parseInt(new String(byteRecvSeq));
			
			byte[] byteRecvSize = new byte[10];
			System.arraycopy(readData, 63, byteRecvSize, 0, byteRecvSize.length);
			int recvSize = Integer.parseInt(new String(byteRecvSize));
			
			int retStatusCd = 00;
			if(recvSeq != modelMap.get(ctx.channel().id()).getSendSeq()) {
				retStatusCd = 1;
			}
			if(recvSize != modelMap.get(ctx.channel().id()).getRecvSize()) {
				retStatusCd += 10;
			}

			//결과(2)
			sendMessage += String.format("%02d", retStatusCd);
			//시퀀스(7)
			sendMessage += String.format("%07d", modelMap.get(ctx.channel().id()).getSendSeq());	
			//총수신크기(10)
			sendMessage += String.format("%010d", modelMap.get(ctx.channel().id()).getRecvSize()); 		
			//전문길이(4)
			sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName()
					, rptFcltyCd, modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim(), "["+sendTelegramCd+"]["
			+String.format("%04d", sendMessage.length()) + "]["+resCd+"][" + sendMessage+"]"));
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);
			
		}else if(recvTelegramCd.equals("03000050")){
//			- ‘00’: 정상, 시퀀스와 크기 둘 다 일치
//			- ‘01’: 시퀀스 불일치
//			- ‘10’: 크기 불일치
//			- ‘11’: 시퀀스와 크기 불일치
//			- ‘99’: 기타 오류
	        
			sendTelegramCd = "03100050";
			System.arraycopy(sendTelegramCd.getBytes(), 0, readData, 42, sendTelegramCd.length()); 
			
			byte[] btyeSendMessage = new byte[52];
			System.arraycopy(readData, 4, btyeSendMessage, 0, btyeSendMessage.length);  
			sendMessage = new String(btyeSendMessage);				
			
			byte[] byteRecvSeq = new byte[7];
			System.arraycopy(readData, 56, byteRecvSeq, 0, byteRecvSeq.length);
			int recvSeq = Integer.parseInt(new String(byteRecvSeq));
			
			byte[] byteRecvSize = new byte[10];
			System.arraycopy(readData, 63, byteRecvSize, 0, byteRecvSize.length);
			int recvSize = Integer.parseInt(new String(byteRecvSize));			

			int retStatusCd = 00;
			if(recvSeq != modelMap.get(ctx.channel().id()).getSendSeq()) {
				retStatusCd = 1;
			}
			if(recvSize != modelMap.get(ctx.channel().id()).getRecvSize()) {
				retStatusCd += 10;
			}			
			
			//결과(2)
			sendMessage += String.format("%02d", retStatusCd);
			//시퀀스(7)
			sendMessage += String.format("%07d", modelMap.get(ctx.channel().id()).getSendSeq());	
			//총수신크기(10)
			sendMessage += String.format("%010d", modelMap.get(ctx.channel().id()).getRecvSize()); 
			//종료일시(14)
			sendMessage += nowDate;
			//전문길이(4)
			sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;
			
			
			bufferMap.get(ctx.channel().id()).close();
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName()
					, rptFcltyCd, modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim(), "["
			+sendTelegramCd+"]["+String.format("%04d", sendMessage.length()) + "]["+resCd+"][" + sendMessage+"]"));
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);			

			
			///////////////// FIU -> CU 응답파일 전송을 위한 데이터 ///////////////////////
			String resFcltyCd = modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD).trim();
			String resDocNo = modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim();
			
			byte[] resMsg = new byte[253];
			System.arraycopy(resFcltyCd.getBytes(), 0, resMsg, 14, resFcltyCd.length());
			System.arraycopy(resDocNo.getBytes(), 0, resMsg, 20, resDocNo.length());
			resService.putMsg(resMsg);
			
		}else if(recvTelegramCd.equals("06000040")){
			sendTelegramCd = "06100040";
			System.arraycopy(sendTelegramCd.getBytes(), 0, readData, 42, sendTelegramCd.length()); 
			sendMessage = new String(readData);	
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName()
					, rptFcltyCd, modelMap.get(ctx.channel().id()).getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim(), "["
			+sendTelegramCd+"]["+String.format("%04d", sendMessage.length()) + "]["+resCd+"][" + sendMessage+"]"));
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);
			
			if(bufferMap.get(ctx.channel().id()) != null) bufferMap.get(ctx.channel().id()).close();
			
		}else {
			System.out.println("=======================> "+recvTelegramCd+" is not definition.");
			ctx.close();
		}
        
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
    	System.out.println("Server exceptionCaught =======================> "+ cause.getMessage());
    	if(bufferMap.get(ctx.channel().id()) != null)
			try {
				bufferMap.get(ctx.channel().id()).close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	cause.printStackTrace();
    	ctx.close();
    }
}
