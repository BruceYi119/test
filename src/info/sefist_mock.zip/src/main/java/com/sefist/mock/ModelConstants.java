package com.sefist.mock;

public class ModelConstants {
	public static String MODEL_TYPE_SEND = "SEND";
	public static String MODEL_TYPE_RECV = "RECV";
	
	public static int SEND_MODEL_LN[] = {4, 10, 6, 20, 10, 2, 20, 20, 15, 100, 6, 30, 8, 2};
	public static String SEND_MODEL_NM[] = {"teleLength", "ifid", "rptFcltyCd", "rptDocNo", "docKndCd", "rptMsgTypeCd"
			, "preRptDocNo", "baseRptDocNo", "trnstnOrder", "rptFileNm", "centAdminCd", "rptUserId", "registDt", "retryCnt"};
	
	public static int RECV_MODEL_LN[] = {4, 10, 6, 20, 2, 2, 3, 2000, 10, 100};
	public static String RECV_MODEL_NM[] = {"teleLength", "ifid", "rptFcltyCd", "rptDocNo", "rptStatusCd", "rptProcType", "rptResCd",
			"rptResMsg", "procHostNm", "recvFileNm"};
	
	public static String MODEL_FIELD_TELE_LENGTH = "teleLength";
	public static String MODEL_FIELD_IF_ID = "ifid";
	public static String MODEL_FIELD_RPT_FCLTY_CD = "rptFcltyCd";
	public static String MODEL_FIELD_RPT_DOC_NO = "rptDocNo";
	public static String MODEL_FIELD_DOC_KND_CD = "docKndCd";
	public static String MODEL_FIELD_RPT_MSG_TYPE_CD = "rptMsgTypeCd";
	public static String MODEL_FIELD_PRE_RPT_DOC_NO = "preRptDocNo";
	public static String MODEL_FIELD_BAS_RPT_DOC_NO = "baseRptDocNo";
	public static String MODEL_FIELD_TRNSTN_ORDER = "trnstnOrder";
	public static String MODEL_FIELD_RPT_FILE_NM = "rptFileNm";
	public static String MODEL_FIELD_CENT_ADMIN_CD = "centAdminCd";
	public static String MODEL_FIELD_RPT_USER_ID = "rptUserId";
	public static String MODEL_FIELD_REGIST_DT = "registDt";
	public static String MODEL_FIELD_RETRY_CNT = "retryCnt";
	
	public static String MODEL_FIELD_RPT_STATUS_CD = "rptStatusCd";
	public static String MODEL_FIELD_RPT_PROC_TYPE = "rptProcType";
	public static String MODEL_FIELD_RPT_RES_CD = "rptResCd";
	public static String MODEL_FIELD_RPT_RES_MSG = "rptResMsg";
	public static String MODEL_FIELD_PROC_HOST_NM = "procHostNm";
	public static String MODEL_FIELD_RECV_FILE_NM = "recvFileNm";

}

