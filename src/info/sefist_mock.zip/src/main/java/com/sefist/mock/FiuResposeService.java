package com.sefist.mock;

import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sefist.socket.FiuClient;

@Component
public class FiuResposeService{
	
	@Autowired
	private SefistProperty prop; 
	private String[] ipList;
	
	private LinkedBlockingQueue<byte[]> queue = new LinkedBlockingQueue<byte[]>();
	
	public FiuResposeService(SefistProperty prop) {
		this.prop = prop;
		
		this.ipList = prop.getClientIp().split(",");
		
		Thread t = new Thread(new FiuResponseClient());
		t.setName("FiuResposeService");
		t.start();
	}
	
	public byte[] getMsg() {
		return queue.poll();
	}
	
	public void putMsg(byte[] msg) {
		try {
			queue.put(msg);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public class FiuResponseClient implements Runnable{
		int ip=0;
		
		@Override
		public void run() {
			
			while(true) {
				if(queue.size() > 0 ){
					try {
						FiuClient client = new FiuClient(ModelFactory.getModel(ModelConstants.MODEL_TYPE_SEND, getMsg())
								, ipList[ip].trim(), prop.getClientPort());

						if(ipList.length > 1) {
							if(ip==0) ip=1;
							else if(ip==1) ip=0;							
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
				Thread t = new Thread();
				try {
					t.sleep(2*1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}	
			}
		}		
	}
	

}
