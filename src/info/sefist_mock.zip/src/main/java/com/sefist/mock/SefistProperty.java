package com.sefist.mock;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class SefistProperty {

	Environment env;
	
	private String sendFilePath;	
	private String recvFilePath;
	private String backFilePath;
	
	private int serverPort;
	private String clientIp;
	private int clientPort;
	

	public SefistProperty(Environment env) {
		this.env = env;
		setProperty();
	}
	
	
	public void setProperty() {
	
		this.sendFilePath = env.getProperty("sefist.fiu.file.send");
		this.recvFilePath = env.getProperty("sefist.fiu.file.recv");
		this.backFilePath = env.getProperty("sefist.fiu.file.backup");

		
		this.serverPort = Integer.parseInt(env.getProperty("sefist.socket.server.port"));
		this.clientIp = env.getProperty("sefist.socket.client.ip");
		this.clientPort = Integer.parseInt(env.getProperty("sefist.socket.client.port"));
		
	
	}
	
	public String getSendFilePath() {
		return sendFilePath;
	}


	public String getRecvFilePath() {
		return recvFilePath;
	}


	public String getBackFilePath() {
		return backFilePath;
	}


	public void setBackFilePath(String backFilePath) {
		this.backFilePath = backFilePath;
	}


	public int getServerPort() {
		return serverPort;
	}


	public String getClientIp() {
		return clientIp;
	}


	public int getClientPort() {
		return clientPort;
	}


}
