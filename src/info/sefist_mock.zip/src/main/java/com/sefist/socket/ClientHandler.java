package com.sefist.socket;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.sefist.mock.Constants;
import com.sefist.mock.LogService;
import com.sefist.mock.ModelConstants;
import com.sefist.mock.ModelFactory;
import com.sefist.mock.ModelFactory.Model;
import com.sefist.mock.SefistException;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.ReadTimeoutException;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;

public class ClientHandler extends ChannelInboundHandlerAdapter {
	ModelFactory.Model model;
	
	private ByteBuf packet;
	private int mustReadSize = 0;
	
    public ClientHandler(Model model) {
    	this.model = model;
    }
    
    private void clearBuffer() { 
    	if (packet != null) {
    		packet.release();
    		packet = null;    	
    	}
    }


    public String getHeader(String telegramCd) {
    	String header = "";
		//트랜젝션 코드(9)
		header += "OFIUXBOGO";
		//시스템 명칭(3)
		header += "FIU";
		//보고기관 코드(6)
		header += String.format("%-6s", model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD).trim());
		//사용자ID(20)
		header += String.format("%-20s", "");
		//전문종별코드 코드(8)
		header += telegramCd;
		//송수신구분(1)
		header += "S";
		//기관구분(1)
		header += "F";
		//계속여부(1)
		header += "Y";
		//응답코드(3)-요구전문에는 항상 "000"
		header += "000";
		
		return header;
    }
    

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
    	ctx.channel().pipeline().addLast(new ReadTimeoutHandler(30));
    	ctx.channel().pipeline().addLast(new WriteTimeoutHandler(30));
		model.setData(ModelConstants.MODEL_FIELD_RPT_PROC_TYPE, "00");
		
    	packet = ctx.alloc().buffer();
    	
		String sendMessage = "";
		sendMessage += this.getHeader("06000010"); //개시전문 77bytes
		
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyymmddHHmmss");
        Calendar c1 = Calendar.getInstance();
        String strToday  = sdf.format(c1.getTime());
				
        //개시요구일시(14)
        sendMessage += strToday;
        //파일확인요구간격(4)
        sendMessage += String.format("%04d", 30); 
        //전송방법(1)
        sendMessage += "B";
        //압축사용여부(1)
        sendMessage += "0";
        //이어받기여부(1)
        sendMessage += "N";
		//전문길이(4)
		sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;
		
		LogService.log.info(LogService.getLogText(getClass().getSimpleName(), model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO)
				, "[06000010]["+String.format("%04d", sendMessage.length()) + "]["+"000"+"][" + sendMessage+"]"));			
		
		ByteBuf messageBuffer = Unpooled.buffer();
		messageBuffer.writeBytes(sendMessage.getBytes());
		ctx.writeAndFlush(messageBuffer);
		
    }

    @Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
    	clearBuffer();
   	
		if(!model.isSendComplete()) throw new Exception("Unexpected Session closed.");
    }   
    
    @Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
    	if(packet == null) packet = ctx.alloc().buffer();

    	ByteBuf b = (ByteBuf)msg;	
    	packet.writeBytes(b);
    	b.release();
    	
    	while(packet.readableBytes() >= 56) {
        	if (mustReadSize == 0) { 
        		byte[] bytes = new byte[4];
        		packet.getBytes(0, bytes);
        		mustReadSize = Integer.parseInt(new String(bytes));
        		LogService.log.debug(LogService.getLogText(getClass().getSimpleName(), null, null, "[mustReadSize]["+mustReadSize+"] [readBytes]["+packet.readableBytes()+"]"));
        	}    		
        	if(packet.readableBytes() < mustReadSize) break;
        		
    		byte[] readData = new byte[mustReadSize];
    		packet.readBytes(readData);
    		messageRead(ctx, readData);
    		LogService.log.debug(LogService.getLogText(getClass().getSimpleName(), null, null, "[remainedBytes]["+packet.readableBytes()+"]"));
    		
    		if(packet.readableBytes() >= 56) {
        		byte[] bytes = new byte[4];
        		packet.getBytes(0, bytes);
        		
        		if(packet.readableBytes() == 73) mustReadSize = 73;
        		else mustReadSize = Integer.parseInt(new String(bytes));
        		LogService.log.debug(LogService.getLogText(getClass().getSimpleName(), null, null, "[mustReadSize]["+mustReadSize+"] [readBytes]["+packet.readableBytes()+"]"));  			
    		}

    		if(packet.readableBytes() == 0) {
        		mustReadSize = 0;
				clearBuffer();
				break;
    		}
    	}    	
    }
    
    public void messageRead(ChannelHandlerContext ctx, byte[] readData) throws Exception {   
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyymmddHHmmss");
        Calendar c1 = Calendar.getInstance();
        String nowDate  = sdf.format(c1.getTime());

		byte[] btyeRecvTelegramCd = new byte[8];
		System.arraycopy(readData, 42, btyeRecvTelegramCd, 0, btyeRecvTelegramCd.length);
		String recvTelegramCd = new String(btyeRecvTelegramCd);
    	
		byte[] btyeResCd = new byte[3];
		System.arraycopy(readData, 53, btyeResCd, 0, btyeResCd.length);   	
		String resCd = new String(btyeResCd);

		byte[] btyeRptFcltyCd = new byte[6];
		System.arraycopy(readData, 16, btyeRptFcltyCd, 0, btyeRptFcltyCd.length);   	
		String rptFcltyCd = new String(btyeRptFcltyCd);			
		
		String rptDocNo = null;
		try {
			rptDocNo = model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim();
		}catch(NullPointerException e) {

		}
		
    	LogService.log.info(LogService.getLogText(getClass().getSimpleName(), rptFcltyCd, rptDocNo
    			, "["+recvTelegramCd+"]["+String.format("%04d", readData.length)+ "]["+resCd+"]["+new String(readData, "EUC-KR")+"]"));					

    	
    	//응답코드 확인
    	if(!resCd.equals("000")) throw new SefistException(resCd);
    	
    	
		String sendMessage = "";
		if(recvTelegramCd.equals("06100010")) {
			sendMessage += this.getHeader("03000020"); 

	    	String fileNm = "CTR_"+model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD).trim()+"_"+nowDate.substring(0, 8)+"_0000001_02.RCV";
			
    	
			//문서종류코드(6)-CTR,STR 확인
			sendMessage += String.format("%-6s", "FIU003");
			//메시지유형코드(2)
			sendMessage += String.format("%-2s", "01");
			//보고문서번호(17)
			sendMessage += String.format("%-17s", model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim());
			//보고일자(8)
			sendMessage += String.format("%-8s", "");
			//종전문서번호(17)
			sendMessage += String.format("%-17s", "");	
			//보고파일명(40)
			sendMessage += String.format("%-40s", fileNm);	 
			//거래순번(15)
			sendMessage += String.format("%-15s", "");
			//기본보고문서번호(17)
			sendMessage += String.format("%-17s", "");
			//중계기관코드(6)
			sendMessage += String.format("%-6s", "");
			//레코드길이(4)
			sendMessage += "0001"; //바이너리만을 사용해서 항상 '0001'
			//압축사용여부(1)
			sendMessage += "0";
			//파일전체크기(10)
			sendMessage += String.format("%010d", 100);
			//전자서명데이터(0~4921)
//			sendMessage += model.getSignVal();
			//전문길이(4)
			sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName(), model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO)
					, "[03000020]["+String.format("%04d", sendMessage.length()) + "]["+"000"+"][" + sendMessage+"]"));			
			
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);		
			
		
		}else if(recvTelegramCd.equals("03100020")){
			sendFile(ctx);
			
			
		}else if(recvTelegramCd.equals("03100040")){
//			- ‘00’: 정상, 시퀀스와 크기 둘 다 일치
//			- ‘01’: 시퀀스 불일치
//			- ‘10’: 크기 불일치
//			- ‘11’: 시퀀스와 크기 불일치			

			byte[] btyeCnfrmRst = new byte[2];
			System.arraycopy(readData, 56, btyeCnfrmRst, 0, btyeCnfrmRst.length);  
			String cnfrmRst = new String(btyeCnfrmRst);			
			
			if(!cnfrmRst.equals("00") || model.isSendComplete()) {
				sendFileComplete(ctx, nowDate);
			}else {
				sendFile(ctx);
			}
			
		}else if(recvTelegramCd.equals("03100050")){
			byte[] btyeCnfrmRst = new byte[2];
			System.arraycopy(readData, 56, btyeCnfrmRst, 0, btyeCnfrmRst.length);  
			String cnfrmRst = new String(btyeCnfrmRst);			

			byte[] btyeSeq = new byte[7];
			System.arraycopy(readData, 58, btyeSeq, 0, btyeSeq.length);  
			String seq = new String(btyeSeq);		
			
			byte[] btyeSize = new byte[10];
			System.arraycopy(readData, 65, btyeSize, 0, btyeSize.length);  
			String size = new String(btyeSize);		
			
			sendMessage += this.getHeader("06000040"); 
			
			//업무종료일시(14)
			sendMessage += nowDate;		
			//전문길이(4)
			sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;		
			
			LogService.log.info(LogService.getLogText(getClass().getSimpleName(), model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO)
					, "[06000040]["+String.format("%04d", sendMessage.length()) + "]["+"000"+"][" + sendMessage+"]"));				
		
			ByteBuf messageBuffer = Unpooled.buffer();
			messageBuffer.writeBytes(sendMessage.getBytes());
			ctx.writeAndFlush(messageBuffer);	
			
			if(!cnfrmRst.equals("00")) {
				String errMsg = "";
				if(cnfrmRst.equals("01")) {
					errMsg = new String("시퀀스 불일치".getBytes("MS949"));
				}else if(cnfrmRst.equals("10")) {
					errMsg = new String("크기 불일치".getBytes("MS949"));
				}else if(cnfrmRst.equals("11")) {
					errMsg = new String("시퀀스와 크기 불일치".getBytes("MS949"));
				}
				model.setData(ModelConstants.MODEL_FIELD_RPT_STATUS_CD, "SF");
				model.setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, "999");
				model.setData(ModelConstants.MODEL_FIELD_RPT_RES_MSG, "[RST_CODE:"+cnfrmRst +"]["+ errMsg 
						+"][SEND:"+model.getSendSeq()+"/"+model.getReadPosition()
						+"][RECV:"+Integer.parseInt(seq)+"/"+Integer.parseInt(size)+"]"); 				
			}else {
				model.setData(ModelConstants.MODEL_FIELD_RPT_STATUS_CD, "SS");
				model.setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, "000");
				model.setData(ModelConstants.MODEL_FIELD_RPT_RES_MSG, new String("전송성공".getBytes("MS949"))); 
			}
			
			model.setSendComplete(true);

			
		}else if(recvTelegramCd.equals("06100040")){	
			ctx.close();
			
		}else {
			StringBuilder sb = new StringBuilder();
			sb.append("[+recvTelegramCd+]");
			sb.append("["+String.format("%04d", readData.length)+"]");
			sb.append("[912]");
			sb.append("["+recvTelegramCd+" is not definition.]"); 			

			LogService.log.error(LogService.getLogText(getClass().getSimpleName()
					, model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO), sb.toString()));
			
			ctx.close();
		}
        
    }
    
	public void sendFileComplete(ChannelHandlerContext ctx, String nowDate) {
 		String sendTelegramCd = "03000050";
		String sendMessage = this.getHeader(sendTelegramCd); 

		//시퀀스(7)
		sendMessage += String.format("%07d", 1);
		//총송신크기(10)
		sendMessage += String.format("%010d", 74);
		//종료일시
		sendMessage += nowDate;
		//수신한 전문길이 반환
		sendMessage = String.format("%04d",sendMessage.length()+4) + sendMessage;
		
		StringBuilder sb = new StringBuilder();
		sb.append("[03000050]");
		sb.append("["+String.format("%04d", sendMessage.length()) + "]");
		sb.append("[000]");
		sb.append("["+sendMessage+"]"); 

		LogService.log.info(LogService.getLogText(getClass().getSimpleName(),
				model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD),
				model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO), sb.toString()));
		
		
		ByteBuf messageBuffer = Unpooled.buffer();
		messageBuffer.writeBytes(sendMessage.getBytes());
		ctx.writeAndFlush(messageBuffer);    	

    }
    
    public void sendFile(ChannelHandlerContext ctx) {
    	String sendMessage = "";

    	SimpleDateFormat sdf  = new SimpleDateFormat("yyyymmddHHmmss");
        Calendar c1 = Calendar.getInstance();
        String nowDate  = sdf.format(c1.getTime());
        
        byte[] fileMsg = null;
        try {
			String temp1 = new String("CTRSTART||03||01||".getBytes("euc-kr"));
			String temp2 = new String(model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD).trim().getBytes("euc-kr"));
			String temp3 = new String("||".getBytes("euc-kr"));
			String temp4 = new String(model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO).trim().getBytes("euc-kr"));
			String temp5 = new String("||"+nowDate.getBytes("euc-kr"));
			String temp6 = new String("||00||접수성공||CTREND".getBytes("euc-kr"));
			
			fileMsg = new byte[temp1.length()+temp2.length()+temp3.length()+temp4.length()+temp5.length()+temp6.length()];
			
			System.arraycopy(temp1.getBytes(), 0, fileMsg, 0, temp1.length());
			System.arraycopy(temp2.getBytes(), 0, fileMsg, temp1.length(), temp2.length());
			System.arraycopy(temp3.getBytes(), 0, fileMsg, temp1.length()+temp2.length(), temp3.length());
			System.arraycopy(temp4.getBytes(), 0, fileMsg, temp1.length()+temp2.length()+temp3.length(), temp4.length());
			System.arraycopy(temp5.getBytes(), 0, fileMsg, temp1.length()+temp2.length()+temp3.length()+temp4.length(), temp5.length());
			System.arraycopy(temp6.getBytes(), 0, fileMsg, temp1.length()+temp2.length()+temp3.length()+temp4.length()+temp5.length(), temp6.length());
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

		byte[] readBuffer = new byte[fileMsg.length];
		byte[] sendByteData = new byte[77+fileMsg.length];
		

		sendMessage = "";
		sendMessage += this.getHeader("03000030"); 
		//시퀀스(7)
		sendMessage += String.format("%07d", 1);
		//기송신크기(10)
		sendMessage += String.format("%010d", 0);
		//데이터길이(4)
		sendMessage += String.format("%04d", fileMsg.length);
		//전문길이(4)
		sendMessage = String.format("%04d", sendByteData.length) + sendMessage;					
		//데이터(1-5043가변)
		System.arraycopy(sendMessage.getBytes(), 0, sendByteData, 0, 77);
		System.arraycopy(fileMsg, 0, sendByteData, 77, fileMsg.length);
		
		StringBuilder sb = new StringBuilder();
		sb.append("[03000030]");
		sb.append("["+String.format("%04d", sendByteData.length) + "]");
		sb.append("[000]");
		LogService.log.info(LogService.getLogText(getClass().getSimpleName()
				, model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO), sb.toString()));

		ByteBuf messageBuffer = Unpooled.buffer();
		messageBuffer.writeBytes(sendByteData);
		ctx.writeAndFlush(messageBuffer);

		//파일확인요구
		sendMessage = "";
		sendMessage += this.getHeader("03000040"); 
		
		//시퀀스(7)
		sendMessage += String.format("%07d", 1);
		//총송신크기(10)
		sendMessage += String.format("%010d", fileMsg.length);
		//전문길이(4)
		sendMessage = String.format("%04d", sendMessage.length()+4) + sendMessage;
		
		LogService.log.info(LogService.getLogText(getClass().getSimpleName(), model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO)
				, "[03000040]["+String.format("%04d", sendMessage.length()) + "]["+"000"+"][" + sendMessage+"]"));	
		
		messageBuffer = Unpooled.buffer();
		messageBuffer.writeBytes(sendMessage.getBytes());
		ctx.writeAndFlush(messageBuffer);
		
		
		model.setSendComplete(true);
    }

    
    @Override
	public void channelReadComplete(ChannelHandlerContext ctx) {
    	ctx.flush();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		model.setData(ModelConstants.MODEL_FIELD_RPT_STATUS_CD, "SF");
    	if(cause instanceof SefistException) {
    		model.setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, cause.getMessage());
    		model.setData(ModelConstants.MODEL_FIELD_RPT_RES_MSG, Constants.errorMap.get(cause.getMessage()) );
    	}else if(cause instanceof ReadTimeoutException) {
        	model.setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, "999");
        	model.setData(ModelConstants.MODEL_FIELD_RPT_RES_MSG, "ReadTimeoutException 30sec" + " SendSequence Status["+model.getSendSeq()+"/"+model.getTotSendSeq()+"]");       		
    	}else {
        	model.setData(ModelConstants.MODEL_FIELD_RPT_RES_CD, "999");
        	model.setData(ModelConstants.MODEL_FIELD_RPT_RES_MSG, cause.getMessage() + " SendSequence Status["+model.getSendSeq()+"/"+model.getTotSendSeq()+"]");   		
    	}
    	
		ctx.close();
    }
    
}