package com.sefist.mock;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ModelFactory {

	@Autowired
	private static SefistProperty prop;
	
	
	public ModelFactory(SefistProperty prop) {
		ModelFactory.prop = prop;
	}
	
	public static Model getModel(String modelType, byte[] message) throws Exception {
		return new Model(modelType, message);
	}

	public static class Model {
		private byte[] message;
		private int modelLn[];
		private String modelNm[];
		private Map<String,String> modelMap = new HashMap<String,String>();
		private File encFile;
		private String signVal;
		private int totSendSeq = 0;
		private long readPosition = 0;
		private int sendSeq = 0;
		private boolean isSendComplete = false;
		private int fileSize = 0;
		private int recvSize = 0;
		
		Model(String modelType, byte[] message) throws Exception {
			if(modelType.equals(ModelConstants.MODEL_TYPE_SEND)) {
				this.modelLn = ModelConstants.SEND_MODEL_LN;
				this.modelNm = ModelConstants.SEND_MODEL_NM;
			}else if(modelType.equals(ModelConstants.MODEL_TYPE_RECV)) {
				this.modelLn = ModelConstants.RECV_MODEL_LN;
				this.modelNm = ModelConstants.RECV_MODEL_NM;			
			}else {
				throw new SefistException("Model type is not exist[" + modelType + "]");
			}
			
			this.message = message;
			buildModel();			
		}
		
		private void buildModel() {
			int lengthSum = 0;
			for(int i=0; i< modelLn.length; i++) {
				byte[] temp = new byte[modelLn[i]];
				System.arraycopy(message, lengthSum, temp, 0, modelLn[i]);
				modelMap.put(modelNm[i], new String(temp));
				lengthSum = lengthSum + modelLn[i];
			}			
		}		
		
		public String getData(String name) {
			return modelMap.get(name);
		}
		
		public String setData(String name, String value) {
			return modelMap.put(name, value);
		}
		
		public File getEncFile() {
			return encFile;
		}

		public void setEncFile(File encFile) {
			this.encFile = encFile;
		}

		public String getSignVal() {
			return signVal;
		}

		public void setSignVal(String signVal) {
			this.signVal = signVal;
		}

		
		public int getSendSeq() {
			return sendSeq;
		}

		public void setSendSeq(int sendSeq) {
			this.sendSeq = sendSeq;
		}

		public boolean isSendComplete() {
			return isSendComplete;
		}

		public void setSendComplete(boolean isSendComplete) {
			this.isSendComplete = isSendComplete;
		}

		public int getFileSize() {
			return fileSize;
		}

		public void setFileSize(int fileSize) {
			this.fileSize = fileSize;
		}

		public int getRecvSize() {
			return recvSize;
		}

		public void setRecvSize(int recvSize) {
			this.recvSize = recvSize;
		}

		public int getTotSendSeq() {
			return totSendSeq;
		}

		public void setTotSendSeq(int totSendSeq) {
			this.totSendSeq = totSendSeq;
		}

		public long getReadPosition() {
			return readPosition;
		}

		public void setReadPosition(long readPosition) {
			this.readPosition = readPosition;
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			
			for(int i=0; i<modelNm.length; i++) {
				String name = modelNm[i].trim();
				String value = modelMap.get(modelNm[i]).trim();
				sb.append(String.format("%15s", name) + "=" + value+"\n");
			}
			
			return sb.toString();
		}
		
	}
	
}
