package com.sefist.socket;

import java.util.ArrayList;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;


public class InitialHandler extends ChannelInitializer<SocketChannel> {
	ArrayList<ChannelHandler> handlers = new ArrayList<ChannelHandler>();
	
	public InitialHandler(ArrayList<ChannelHandler> handlers) {
		this.handlers = handlers;
	}
	
    @Override
	public void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline pipe = ch.pipeline();
        for(ChannelHandler handler : handlers) {
        	pipe.addLast(handler);
        }
    }	
    
    public ArrayList<ChannelHandler> getHandlers() {
		return handlers;
	}


	public void setHandlers(ArrayList<ChannelHandler> handlers) {
		this.handlers = handlers;
	}

}