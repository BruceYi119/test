package com.sefist.mock;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

@Component
public class ShutdownListener implements ApplicationListener<ContextClosedEvent> {
	

	
	public ShutdownListener() {

	}
	
	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		LogService.log.info(LogService.getLogText(getClass().getSimpleName(), null, null, "sefist_mock switch off."));
	}
}
