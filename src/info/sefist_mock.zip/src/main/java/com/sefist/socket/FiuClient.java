package com.sefist.socket;

import java.util.ArrayList;

import com.sefist.mock.LogService;
import com.sefist.mock.ModelConstants;
import com.sefist.mock.ModelFactory;
import com.sefist.mock.ModelFactory.Model;
import com.sefist.mock.SefistException;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

public class FiuClient { 
	private EventLoopGroup workerGroup = new NioEventLoopGroup();
	private Bootstrap bootstrap = new Bootstrap();
	
	private String host;
	private int port;
	private InitialHandler handlers;
	
	Model model;
	
	public FiuClient(ModelFactory.Model model, String host, int port) throws Exception{
		this.model = model;
		this.host = host;
		this.port = port;
		
		ArrayList<ChannelHandler> handlers = new ArrayList<ChannelHandler>();
		ClientHandler clientHandler = new ClientHandler(model);
		handlers.add(clientHandler);
		this.handlers = new InitialHandler(handlers);
		
		try {
			this.run();		
		}catch(Exception e) {
			throw new SefistException("IFU->CU Connection failed.");
		}
	}


	public void stop() {
    	bootstrap.config().group().shutdownGracefully();	
	}
	
	public void run() throws Exception{
	    bootstrap.group(workerGroup)
	     .channel(NioSocketChannel.class)
	     .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5*1000)
 	     .handler(handlers);  	
  
	    try {
		    Channel channel = bootstrap.connect(host, port).sync().channel();  
		    LogService.log.info(LogService.getLogText(getClass().getSimpleName(), model.getData(ModelConstants.MODEL_FIELD_RPT_FCLTY_CD), model.getData(ModelConstants.MODEL_FIELD_RPT_DOC_NO)
		    		, "FIU Socket Client stared on ip&port [" + host + ":" + port+"]"));
		    channel.closeFuture().sync();
	    } catch (InterruptedException e) {
			e.printStackTrace();
	    } finally {
	    	bootstrap.config().group().shutdownGracefully();
	    }	    
	    
	}

}

