package com.sefist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SefistMockApplicationTests {

	@Test
	void contextLoads() {
	}

}
